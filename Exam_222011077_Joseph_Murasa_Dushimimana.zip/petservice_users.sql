-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2024 at 09:53 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pet_user_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `petservice_users`
--

CREATE TABLE `petservice_users` (
  `user_id` int(100) NOT NULL,
  `Firstname` varchar(255) NOT NULL,
  `Lastname` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Gender` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `petservice_users`
--

INSERT INTO `petservice_users` (`user_id`, `Firstname`, `Lastname`, `Email`, `Gender`, `Password`) VALUES
(1, 'Murasa', 'Joseph', 'dushimejeph@gmail.com', 'Male', '123'),
(2, 'Imanzi', 'Eric', 'imanzieric99@gmail.com', 'Male', '135'),
(3, 'Niyoyita', 'Bella', 'bellaniyoyita@gmail.com', 'Female', '1357'),
(4, 'Joseph', 'Murasa Dushimimana', 'dushimimanamurasajoseph@gmail.com', 'Male', 'rwanda'),
(5, 'Imanzi', 'Eric', 'imanzieric@gmail.com', 'Male', '1234'),
(6, 'Joseph', 'Rwema', 'dushimejeph@gmail.com', 'Male', '1234'),
(7, 'Sabrina', 'Rutagengwa', 'sabrina@gmail.com', 'Female', '1357'),
(8, 'Joseph', 'Murasa', 'joseph', 'Male', '222011077');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `petservice_users`
--
ALTER TABLE `petservice_users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `petservice_users`
--
ALTER TABLE `petservice_users`
  MODIFY `user_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
